/*
 * @Author: ZYT
 * @Date: 2025-07-28 15:39:06
 * @LastEditors: ZYT
 * @LastEditTime: 2025-07-28 15:47:28
 * @FilePath: \EC_tesr_F4\User\oled\oled.h
 * @Brief: 
 * 
 * Copyright (c) 2025 by zyt, All Rights Reserved. 
 */
#ifndef __OLED_H
#define __OLED_H 

#include "main.h"
#include "gpio.h"
#include "stdlib.h"	
#include "stm32f4xx_hal.h"
#include <stdio.h>
#include <stdlib.h>
#include "My_spi.h"
//f4用这个
#define  OLED_RES_Pin oled_RES_Pin   //RES
#define  OLED_DC_Pin oled_DC_Pin    //DC
#define  OLED_CS_Pin oled_CS_Pin    //CS

#define OLED_RES_GPIO_Port oled_RES_GPIO_Port //RES
#define OLED_DC_GPIO_Port oled_DC_GPIO_Port    //DC
#define OLED_CS_GPIO_Port oled_CS_GPIO_Port    //CS

//f1用这个
// #define  OLED_RES_Pin GPIO_PIN_4   //RES
// #define  OLED_DC_Pin GPIO_PIN_6    //DC
// #define  OLED_CS_Pin GPIO_PIN_0    //CS

// #define OLED_RES_GPIO_Port GPIOA   //RES
// #define OLED_DC_GPIO_Port GPIOA    //DC
// #define OLED_CS_GPIO_Port GPIOB    //CS


#define OLED_RES_Clr() HAL_GPIO_WritePin(OLED_RES_GPIO_Port,OLED_RES_Pin,GPIO_PIN_RESET)//RES
#define OLED_RES_Set() HAL_GPIO_WritePin(OLED_RES_GPIO_Port,OLED_RES_Pin,GPIO_PIN_SET)

#define OLED_DC_Clr() HAL_GPIO_WritePin(OLED_DC_GPIO_Port,OLED_DC_Pin,GPIO_PIN_RESET)//DC
#define OLED_DC_Set() HAL_GPIO_WritePin(OLED_DC_GPIO_Port,OLED_DC_Pin,GPIO_PIN_SET)
 		     
#define OLED_CS_Clr()  HAL_GPIO_WritePin(OLED_CS_GPIO_Port,OLED_CS_Pin,GPIO_PIN_RESET)//CS
#define OLED_CS_Set()  HAL_GPIO_WritePin(OLED_CS_GPIO_Port,OLED_CS_Pin,GPIO_PIN_SET)

#define OLED_CMD  0	
#define OLED_DATA 1	

#define uint8_t unsigned char
#define uint32_t unsigned int
#define WHICH_SPI &hspi1

void OLED_ClearPoint(uint8_t x,uint8_t y);
void OLED_ColorTurn(uint8_t i);
void OLED_DisplayTurn(uint8_t i);
void OLED_WR_Byte(uint8_t dat,uint8_t cmd);
void OLED_DisPlay_On(void);
void OLED_DisPlay_Off(void);
void OLED_Refresh(void);
void OLED_Clear(void);
void OLED_DrawPoint(uint8_t x,uint8_t y);
void OLED_DrawLine(uint8_t x1,uint8_t y1,uint8_t x2,uint8_t y2);
void OLED_DrawSquare(uint8_t x1,uint8_t y1,uint8_t x2,uint8_t y2);
void OLED_DrawCircle(uint8_t x,uint8_t y,uint8_t r);
void OLED_ShowChar(uint8_t x,uint8_t y,uint8_t chr,uint8_t size1);
void OLED_ShowString(uint8_t x,uint8_t y,uint8_t *chr,uint8_t size1);
void OLED_ShowNum(uint8_t x,uint8_t y,uint32_t num,uint8_t len,uint8_t size1);
void OLED_ShowChinese(uint8_t x,uint8_t y,uint8_t num,uint8_t size1);
void OLED_ScrollDisplay(uint8_t num,uint8_t space);
void OLED_WR_BP(uint8_t x,uint8_t y);
void OLED_ShowPicture(uint8_t x0,uint8_t y0,uint8_t x1,uint8_t y1,uint8_t BMP[]);
void OLED_Printf(uint8_t str[]);
void OLED_Init(void);
void OLED_DrawGIF(unsigned char x0, unsigned char y0,unsigned char x1, unsigned char y1, unsigned char k, int m, unsigned char GIF[][m]);                  
                         
#endif