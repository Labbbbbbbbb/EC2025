/*
 * @Author: ZYT
 * @Date: 2025-07-29 22:16:23
 * @LastEditors: ZYT
 * @LastEditTime: 2025-07-29 22:56:48
 * @FilePath: \ED_Trail\UserCode\Upper\Upper_pantilt\Upper_pantilt.c
 * @Brief: 
 * 
 * Copyright (c) 2025 by zyt, All Rights Reserved. 
 */
#include "Upper_pantilt.h"

/**
 * @brief   循迹线程
 */
void Upper_pantilt_Task(void *argument)
{
    osDelay(100);
    WheelMode(1, 0);
    WheelMode(2, 0);
    for (;;) {
        WritePosEx(1, 2200, 2400, 50); // pitch轴 增大向上
        WritePosEx(2, 2220, 2400, 50); // yaw轴 增大往右
        // WriteSpe(2,spe2,50);
        printf("%d,%d\n", ReadPos(1), ReadPos(2));
    }
}

void Upper_pantilt_TaskStart(void)
{
    const osThreadAttr_t upper_pantilt_Task_attributes = {
        .name       = "upper_pantilt_Task",
        .stack_size = 128 * 10,
        .priority   = (osPriority_t)osPriorityNormal,
    };
    osThreadNew(Upper_pantilt_Task, NULL, &upper_pantilt_Task_attributes);
}


