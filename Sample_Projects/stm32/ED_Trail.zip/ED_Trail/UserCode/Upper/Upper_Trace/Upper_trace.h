#ifndef __UPPER_TRACE_H
#define __UPPER_TRACE_H

#include "Upperstart.h"

void Upper_Trace_TaskStart(void);
void Upper_Trace_Task(void *argument);

#endif