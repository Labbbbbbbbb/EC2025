#include "USART_Init.h"
void Gantry_usart_init()
{
    // __HAL_UART_ENABLE_IT(&huart6, UART_IT_RXNE);
    // HAL_UART_Receive_IT(&huart6, Rxbuffer[4], sizeof(Rxbuffer[4]));
}