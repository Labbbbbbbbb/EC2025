#ifndef __USART_INIT_H
#define __USART_INIT_H

#include "UpperStart.h"

void Gantry_usart_init();

#endif
