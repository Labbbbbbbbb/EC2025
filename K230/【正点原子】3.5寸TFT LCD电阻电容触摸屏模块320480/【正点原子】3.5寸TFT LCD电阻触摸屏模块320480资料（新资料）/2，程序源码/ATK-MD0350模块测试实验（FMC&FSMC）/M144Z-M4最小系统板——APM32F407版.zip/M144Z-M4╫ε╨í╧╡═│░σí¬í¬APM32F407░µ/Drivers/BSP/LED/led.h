/**
 ****************************************************************************************************
 * @file        led.h
 * @author      ����ԭ���Ŷ�(ALIENTEK)
 * @version     V1.0
 * @date        2022-10-15
 * @brief       LED��������
 * @license     Copyright (c) 2020-2032, �������������ӿƼ����޹�˾
 ****************************************************************************************************
 * @attention
 * 
 * ʵ��ƽ̨:����ԭ�� APM32F407��Сϵͳ��
 * ������Ƶ:www.yuanzige.com
 * ������̳:www.openedv.com
 * ��˾��ַ:www.alientek.com
 * �����ַ:openedv.taobao.com
 * 
 ****************************************************************************************************
 */

#ifndef __LED_H
#define __LED_H

#include "./SYSTEM/sys/sys.h"
#include "apm32f4xx_gpio.h"

/* ���Ŷ��� */
#define LED0_GPIO_PORT          GPIOF
#define LED0_GPIO_PIN           GPIO_PIN_9
#define LED0_GPIO_CLK_ENABLE()  do{ RCM_EnableAHB1PeriphClock(RCM_AHB1_PERIPH_GPIOF); }while(0)

#define LED1_GPIO_PORT          GPIOF
#define LED1_GPIO_PIN           GPIO_PIN_10
#define LED1_GPIO_CLK_ENABLE()  do{ RCM_EnableAHB1PeriphClock(RCM_AHB1_PERIPH_GPIOF); }while(0)

/* IO���� */
#define LED0(x)                 do{ x ?                                             \
                                    GPIO_SetBit(LED0_GPIO_PORT, LED0_GPIO_PIN) :    \
                                    GPIO_ResetBit(LED0_GPIO_PORT, LED0_GPIO_PIN);   \
                                }while(0)

#define LED1(x)                 do{ x ?                                             \
                                    GPIO_SetBit(LED1_GPIO_PORT, LED1_GPIO_PIN) :    \
                                    GPIO_ResetBit(LED1_GPIO_PORT, LED1_GPIO_PIN);   \
                                }while(0)

#define LED0_TOGGLE()           do{ GPIO_ToggleBit(LED0_GPIO_PORT, LED0_GPIO_PIN); }while(0)
#define LED1_TOGGLE()           do{ GPIO_ToggleBit(LED1_GPIO_PORT, LED1_GPIO_PIN); }while(0)

/* �������� */
void led_init(void);    /* ��ʼ��LED */

#endif
